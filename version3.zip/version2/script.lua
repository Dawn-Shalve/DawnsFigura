for key, value in pairs(armor_model) do
    value.setEnabled(false)    
end

for key, value in pairs(vanilla_model) do
    value.setEnabled(false)
end
lastHealth = 0

function tick()
  local health = player.getHealth()
  if health < lastHealth then
sound.playSound("entity.bee.hurt", player.getPos(), {1, 1})
  end
  lastHealth = health
end
local status = 0
local piss = 0
local animkey = keybind.newKey("Get Down", "U")

network.registerPing("getdown")
network.registerPing("getup")

function getdown()
	status = 1
	piss = 0
end

function getup()
	status = 0
	piss = 0
	for key, value in pairs(model) do
		value.setPos({0, 0, 0})
		value.setRot({0, 0, 0})
	end
end

function tick()
	piss = piss + 1

	if animkey.isPressed() and status == 0 and piss > 5 then
		network.ping("getdown")
	elseif animkey.isPressed() and status == 1 and piss > 5 then
		network.ping("getup")
	end
end

function seizure()
	for key, value in pairs(model) do
		value.setPos({math.random()*10-5, math.random()*-0, math.random()*10-5})
		value.setRot({math.random()*360, math.random()*360, math.random()*360})
	end
	model.LeftLeg.setPos({math.random()*10-5, math.random()*-20-20, math.random()*10-5})
	model.RightLeg.setPos({math.random()*10-5, math.random()*-20-20, math.random()*10-5})
end

function reset()
	for key, value in pairs(model) do
		value.setPos({0, 0, 0})
		value.setRot({0, 0, 0})
	end
end

function render()
	if (status == 1) then
		if (piss >= 0 and piss <= 170) then seizure() end
		if (piss >= 170 and piss <= 190) then
			if ((piss + 4) % 8 == 0) then
				reset()
				model.LeftLeg.setRot({0, 0, 10})
				model.RightLeg.setRot({0, 0, 10})
				model.Body.setRot({0, 0, -10})
				model.RightArm.setPos({0, -4, 0})
				model.RightArm.setRot({180, 0, -20})
				model.LeftArm.setPos({0, -4, 0})
				model.LeftArm.setRot({180, 0, 30})
			end
			if piss % 8 == 0 then
				reset()
				model.LeftLeg.setRot({0, 0, -10})
				model.RightLeg.setRot({0, 0, -10})
				model.Body.setRot({0, 0, 10})
				model.RightArm.setPos({0, -4, 0})
				model.RightArm.setRot({180, 0, -30})
				model.LeftArm.setPos({0, -4, 0})
				model.LeftArm.setRot({180, 0, 20})
			end
		end
		if (piss >= 190 and piss <= 210) then seizure() end
		if (piss >= 210 and piss <= 230) then
			if ((piss + 4) % 8 == 0) then
				reset()
				model.LeftLeg.setRot({0, 0, 10})
				model.RightLeg.setRot({0, 0, 10})
				model.Body.setRot({0, 0, -10})
				model.RightArm.setPos({0, -4, 0})
				model.RightArm.setRot({180, 0, -20})
				model.LeftArm.setPos({0, -4, 0})
				model.LeftArm.setRot({180, 0, 30})
			end
			if piss % 8 == 0 then
				reset()
				model.LeftLeg.setRot({0, 0, -10})
				model.RightLeg.setRot({0, 0, -10})
				model.Body.setRot({0, 0, 10})
				model.RightArm.setPos({0, -4, 0})
				model.RightArm.setRot({180, 0, -30})
				model.LeftArm.setPos({0, -4, 0})
				model.LeftArm.setRot({180, 0, 20})
			end
		end
		if (piss >= 230 and piss <= 270) then
			if ((piss + 3) % 6 == 0) then
				reset()
				model.LeftLeg.setRot({-10, 0, 0})
				model.RightLeg.setRot({-10, 0, 0})
				model.Body.setRot({10, 0, 0})
				model.RightArm.setPos({1, -2, 2})
				model.RightArm.setRot({200, 0, 30})
				model.LeftArm.setPos({-1, -2, 2})
				model.LeftArm.setRot({200, 0, -30})
			end
			if piss % 6 == 0 then
				reset()
				model.LeftLeg.setRot({10, 0, 0})
				model.RightLeg.setRot({10, 0, 0})
				model.Body.setRot({-10, 0, 0})
				model.RightArm.setPos({1, -2, 2})
				model.RightArm.setRot({200, 0, 30})
				model.LeftArm.setPos({-1, -2, 2})
				model.LeftArm.setRot({200, 0, -30})
			end
		end
		if (piss >= 270 and piss <= 310) then
			if ((piss + 10) % 20 == 0) then
				reset()
				model.LeftLeg.setPos({0, 0, 0})
				model.LeftLeg.setRot({0, 0, 0})
				model.RightLeg.setPos({-4, 0, -2})
				model.RightLeg.setRot({20, -45, 10})
				model.Body.setRot({0, 0, 0})
				model.RightArm.setPos({0, 0, 0})
				model.RightArm.setRot({100, -90, 0})
				model.LeftArm.setPos({0, 2, 0})
				model.LeftArm.setRot({100, -40, 20})
			end
			if piss % 20 == 0 then
				reset()
				model.LeftLeg.setPos({4, 0, -2})
				model.LeftLeg.setRot({20, 45, -10})
				model.RightLeg.setPos({0, 0, 0})
				model.RightLeg.setRot({0, 0, 0})
				model.Body.setRot({0, 0, 0})
				model.RightArm.setPos({0, 2, 0})
				model.RightArm.setRot({100, 40, 20})
				model.LeftArm.setPos({0, 0, 0})
				model.LeftArm.setRot({100, 90, 0})
			end
		end
		if (piss >= 310 and piss <= 480) then seizure() end
		if (piss >= 480 and piss <= 500) then
			if ((piss + 4) % 8 == 0) then
				reset()
				model.LeftLeg.setRot({0, 0, 10})
				model.RightLeg.setRot({0, 0, 10})
				model.Body.setRot({0, 0, -10})
				model.RightArm.setPos({0, -4, 0})
				model.RightArm.setRot({180, 0, -20})
				model.LeftArm.setPos({0, -4, 0})
				model.LeftArm.setRot({180, 0, 30})
			end
			if piss % 8 == 0 then
				reset()
				model.LeftLeg.setRot({0, 0, -10})
				model.RightLeg.setRot({0, 0, -10})
				model.Body.setRot({0, 0, 10})
				model.RightArm.setPos({0, -4, 0})
				model.RightArm.setRot({180, 0, -30})
				model.LeftArm.setPos({0, -4, 0})
				model.LeftArm.setRot({180, 0, 20})
			end
		end
		if (piss >= 500 and piss <= 520) then seizure() end
		if (piss >= 520 and piss <= 540) then
			if ((piss + 4) % 8 == 0) then
				reset()
				model.LeftLeg.setRot({0, 0, 10})
				model.RightLeg.setRot({0, 0, 10})
				model.Body.setRot({0, 0, -10})
				model.RightArm.setPos({0, -4, 0})
				model.RightArm.setRot({180, 0, -20})
				model.LeftArm.setPos({0, -4, 0})
				model.LeftArm.setRot({180, 0, 30})
			end
			if piss % 8 == 0 then
				reset()
				model.LeftLeg.setRot({0, 0, -10})
				model.RightLeg.setRot({0, 0, -10})
				model.Body.setRot({0, 0, 10})
				model.RightArm.setPos({0, -4, 0})
				model.RightArm.setRot({180, 0, -30})
				model.LeftArm.setPos({0, -4, 0})
				model.LeftArm.setRot({180, 0, 20})
			end
		end
		if (piss >= 540 and piss <= 580) then
			if ((piss + 3) % 6 == 0) then
				reset()
				model.LeftLeg.setRot({-10, 0, 0})
				model.RightLeg.setRot({-10, 0, 0})
				model.Body.setRot({10, 0, 0})
				model.RightArm.setPos({1, -2, 2})
				model.RightArm.setRot({200, 0, 30})
				model.LeftArm.setPos({-1, -2, 2})
				model.LeftArm.setRot({200, 0, -30})
			end
			if piss % 6 == 0 then
				reset()
				model.LeftLeg.setRot({10, 0, 0})
				model.RightLeg.setRot({10, 0, 0})
				model.Body.setRot({-10, 0, 0})
				model.RightArm.setPos({1, -2, 2})
				model.RightArm.setRot({200, 0, 30})
				model.LeftArm.setPos({-1, -2, 2})
				model.LeftArm.setRot({200, 0, -30})
			end
		end
		if (piss >= 580 and piss <= 620) then
			if ((piss + 10) % 20 == 0) then
				reset()
				model.LeftLeg.setPos({0, 0, 0})
				model.LeftLeg.setRot({0, 0, 0})
				model.RightLeg.setPos({-4, 0, -2})
				model.RightLeg.setRot({20, -45, 10})
				model.Body.setRot({0, 0, 0})
				model.RightArm.setPos({0, 0, 0})
				model.RightArm.setRot({100, -90, 0})
				model.LeftArm.setPos({0, 2, 0})
				model.LeftArm.setRot({100, -40, 20})
			end
			if piss % 20 == 0 then
				reset()
				model.LeftLeg.setPos({4, 0, -2})
				model.LeftLeg.setRot({20, 45, -10})
				model.RightLeg.setPos({0, 0, 0})
				model.RightLeg.setRot({0, 0, 0})
				model.Body.setRot({0, 0, 0})
				model.RightArm.setPos({0, 2, 0})
				model.RightArm.setRot({100, 40, 20})
				model.LeftArm.setPos({0, 0, 0})
				model.LeftArm.setRot({100, 90, 0})
			end
		end
		if (piss >= 620 and piss <= 700) then seizure() end
		if (piss >= 700 and piss <= 720) then reset() end
	end
end
function point()
  local playerList = world.getFiguraPlayers()
  local fran = nil
  for key, value in pairs(playerList) do
    if value.getUUID() == "66a6c5c4-963b-4b73-a0d9-162faedd8b7f" then
      fran = value
      break
    end
  end

  if (fran) then
    local franPos = fran.getPos()
    local omoRot = player.getRot()

    local rightArm = player.getPos() + lengthDir(0.3, omoRot.y + 90) + vectors.of({0,1,0})
    local leftArm = player.getPos() + lengthDir(0.3, omoRot.y - 90) + vectors.of({0,1,0})
    local rDist = rightArm.distanceTo(franPos)
    local lDist = leftArm.distanceTo(franPos)
    
    local left = rDist > lDist
    model.Base.LEFT_ARM.setRot({0,0,0})
    model.Base.RIGHT_ARM.setRot({0,0,0})
    if (left) then
      model.Base.LEFT_ARM.setRot({0,0,-90})
    else
      model.Base.RIGHT_ARM.setRot({0,0,90})
    end
  end
end

-- helper function to get a point rotated relative to myself
function lengthDir(dist, angle)
  local lengthDir_x = math.sin(-math.rad(angle)) * dist
  local lengthDir_z = math.cos(-math.rad(angle)) * dist
  return vectors.of({lengthDir_x, 0, lengthDir_z})
end
function render(delta)
  particle.addParticle("portal", {player.getPos().x +  math.random() - 0.5, player.getPos().y +  math.random(), player.getPos().z + math.random() - 0.5, math.random(-1,1),  math.random(-1,1),  math.random(-1,1)})
end
