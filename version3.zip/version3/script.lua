for key, value in pairs(armor_model) do
    value.setEnabled(false)    
end

for key, value in pairs(vanilla_model) do
    value.setEnabled(false)
end
lastHealth = 0

function tick()
  local health = player.getHealth()
  if health < lastHealth then
sound.playSound("entity.bee.hurt", player.getPos(), {1, 1})
  end
  lastHealth = health
end
--=================================
CharacterName='Dawn' --use JSON encoding or normal string (for JSON generator head to https://minecraft.tools/en/json_text.php)
RealName = '' --leave blank for script to figure it out
startasreal = false --whether or not you start as "real" you
--=================================
network.registerPing("NameSwitch")
item8 = item_stack.createItem("minecraft:player_head") 
function Slot8()
    if playerPos ~= nil then
        sound.playSound("minecraft:item.armor.equip_generic", {playerPos.x, playerPos.y, playerPos.z, 0.75, 1})
    end
    if startasreal then 
        word8 = RealName
        word8dis = RealNameDis
        item8.setTag('{SkullOwner:{Id:[I;1590668272,1381189552,-1538418164,-1841266247],Properties:{textures:[{Value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYmViNTg4YjIxYTZmOThhZDFmZjRlMDg1YzU1MmRjYjA1MGVmYzljYWI0MjdmNDYwNDhmMThmYzgwMzQ3NWY3In19fQ=="}]}}}')
    else 
        word8 = CharacterName
        word8dis = CharacterNameDis
        item8.setTag('{SkullOwner:{Id:[I;55185054,-2025500730,-2043050837,-997286030],Properties:{textures:[{Value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYTkyZTMxZmZiNTljOTBhYjA4ZmM5ZGMxZmUyNjgwMjAzNWEzYTQ3YzQyZmVlNjM0MjNiY2RiNDI2MmVjYjliNiJ9fX0="}]}}}')
    end
    startasreal = not startasreal
    action_wheel.SLOT_8.setTitle("Current Name: " .. word8dis)
    action_wheel.SLOT_8.setItem(item8)
    network.ping("NameSwitch", word8)
end
action_wheel.SLOT_8.setFunction(Slot8)
function player_init()
    playerPos = player.getPos()
    if RealName == '' then RealName = player.getName() end
    CharacterNameDis = ""
    for i in string.gmatch(CharacterName, '"text":"%w+"') do CharacterNameDis=CharacterNameDis..string.match(string.gsub(i, '"text":', ''), "%w+") end
    RealNameDis = ""
    for i in string.gmatch(RealName, '"text":"%w+"') do RealNameDis=RealNameDis..string.match(string.gsub(i, '"text":', ''), "%w+") end
    if RealNameDis == "" then RealNameDis = RealName end
    if CharacterNameDis == "" then CharacterNameDis = CharacterName end
    Slot8()
end
function NameSwitch(val)
    nameplate.CHAT.setText(val)
    nameplate.ENTITY.setText(val)
    nameplate.LIST.setText(val)
end
function tick()
    playerPos = player.getPos()
end